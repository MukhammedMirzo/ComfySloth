import React from "react";

const StripeCheckout = () => {
  return <div>StripeCheckout</div>;
};

export default StripeCheckout;
