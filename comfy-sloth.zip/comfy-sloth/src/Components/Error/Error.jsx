import React from "react";

const Error = () => {
  return (
    <div className="section section-center text-center">
      <h2>There was an Error...</h2>
    </div>
  );
};

export default <h2>Error</h2>;
