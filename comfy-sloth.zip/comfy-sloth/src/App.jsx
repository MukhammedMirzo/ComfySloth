import React from "react";
import "./App.css";
import MainRouter from "./Routes/MainRouter";

const App = () => {
  return (
    <div>
      <MainRouter />
    </div>
  );
};

export default App;
