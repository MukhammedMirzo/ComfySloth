import React from "react";

const PrivateRoute = () => {
  return <div>PrivateRoute</div>;
};

export default PrivateRoute;
