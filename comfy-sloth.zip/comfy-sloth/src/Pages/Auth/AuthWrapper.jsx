import React from "react";

const AuthWrapper = () => {
  return <div>AuthWrapper</div>;
};

export default AuthWrapper;
